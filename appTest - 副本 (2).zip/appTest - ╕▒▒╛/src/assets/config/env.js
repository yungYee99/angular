(function (window) {
    window.__env = window.__env || {};
    // API url
    window.__env.securityApiBaseUrl = 'http://192.168.109.38:9002';
    window.__env.signalRUrl = 'http://192.168.109.38:9004/wynnhub';
    window.__env.securityApiTimeoutInSec = 30;
    window.__env.uploadApiTimeoutInSec = 120;
}(this));