import { Component } from '@angular/core';
@Component({
selector: 'detail-page',
templateUrl: './detail.component.html',
styleUrls: ['./detail.component.css']
})
export class detailComponent {}