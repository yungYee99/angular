const uuidv1 = require('uuid/v1')
const sd = require('silly-datetime')
const type = require('./type')
const crypto = require('crypto')

const Tools = {
  /**
   *获取uuid， 当前的uuid中间没有连接横线
   */
  getUUID () {
    let uuid = uuidv1()
    return uuid.toString().replace(/[-]/g, '')
  },
  /**
 *获取当前时间时间格式为YYYYMMDDhhmmss
 */
  getCurrentDateTime () {
    return sd.format(new Date(), 'YYYYMMDDHHmmss')
  },

  /**
   *base64 encoding
   * @param {*} data
   */
  ObjectToBase64 (data) {
    if (type.isJSON(data)) {
      data = JSON.stringify(data)
    }

    return Buffer.from(data, 'utf8').toString('base64')
  },
  /**
   * 返回距 1970 年 1 月 1 日之间的秒数
   */
  getTimeStamp () {
    let d = new Date()
    return Math.floor(d.getTime() / 1000)
  },
  digest (message) {
    return crypto.createHash('sha256').update(message).digest('hex')
  },
  generateNonceStr () {
    let nonceStr = ''
    let length = 16
    let strPol = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz'
    for (let i = 0; i < length; i++) {
      nonceStr = nonceStr + strPol[Math.floor(Math.random() * strPol.length)]
    }
    return nonceStr
  },

  /**
   * base64 decode
   * @param {*} data 解密的数据
   * @param {*Encoding} encoding 编码方式
   */
  base64ToObject (data, encoding) {
    data = JSON.stringify(data)
    let result = Buffer.from(data, 'base64').toString(encoding)
    try {
      result = JSON.parse(result)
    } catch (error) {

    }

    return result
  }
}

module.exports = Tools
