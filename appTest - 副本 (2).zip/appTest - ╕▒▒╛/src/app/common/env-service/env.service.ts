import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EnvService {
  public securityApiBaseUrl = '';
  public signalRUrl = '';
  public securityApiTimeoutInSec: number;
  public uploadApiTimeoutInSec: number;
  constructor() { }

}
