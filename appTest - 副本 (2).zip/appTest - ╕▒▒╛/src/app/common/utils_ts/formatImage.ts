export function formatImage(img) {
  if (!img) {
    return '';
  }
  const index = img.indexOf(',') + 1;

  img = img.substring(index);
  return img;
}
