export const CAN_LOGIN_SECURITY_MGM = 'CanLoginSecurityMgm';

// Barred player
export const CAN_VIEW_BARRED_PLAYER_AND_HISTORY = 'CanViewBarredPlayerAndHistory';
export const CAN_ADD_BARRED_PLAYER = 'CanAddBarredPlayer';
export const CAN_EDIT_BARRED_PLAYER = 'CanEditBarredPlayer';
export const CAN_DELETE_BARRED_PLAYER = 'CanDeleteBarredPlayer';
export const CAN_BATCH_UPLOAD_BARRED_PLAYER_LIST = 'CanBatchUploadBarredPlayerList';
export const CAN_BATCH_UPLOAD_BARRED_PLAYER_PHOTO = 'CanBatchUploadBarredPlayerPhoto';
export const CAN_UPLOAD_BARRED_PLAYER_PHOTO = 'CanUploadBarredPlayerPhoto';
export const CAN_EXPORT_BARRED_PLAYER_LIST = 'CanExportBarredPlayerList';
export const CAN_UNBAR_BARRED_PLAYER = 'CanUnbarBarredPlayer';
export const CAN_LINK_BARRED_PLAYER_TO_GCM_PLAYER = 'CanLinkBarredPlayerToGCMPlayer';
export const CAN_UNLINK_BARRED_PLAYER_TO_GCM_PLAYER = 'CanUnlinkBarredPlayerToGCMPlayer';
export const CAN_VIEW_PERSONAL_BARRED_HISTORY = 'CanViewPersonalBarredHistory';

// Flag player
export const CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY = 'CanViewFlaggedPlayerAndHistory';
export const CAN_ADD_FLAGGED_PLAYER = 'CanAddFlaggedPlayer';
export const CAN_EDIT_FLAGGED_PLAYER = 'CanEditFlaggedPlayer';
export const CAN_DELETE_FLAGGED_PLAYER = 'CanDeleteFlaggedPlayer';
export const CAN_BATCH_UPLOAD_FLAGGED_PLAYER_LIST = 'CanBatchUploadFlaggedPlayerList';
export const CAN_BATCH_UPLOAD_FLAGGED_PLAYER_PHOTO = 'CanBatchUploadFlaggedPlayerPhoto';
export const CAN_UPLOAD_FLAGGED_PLAYER_PHOTO = 'CanUploadFlaggedPlayerPhoto';
export const CAN_EXPORT_FLAGGED_PLAYER_LIST = 'CanExportFlaggedPlayerList';
export const CAN_UNFLAG_FLAGGED_PLAYER = 'CanUnflagFlaggedPlayer';
export const CAN_LINK_FLAGGED_PLAYER_TO_GCM_PLAYER = 'CanLinkFlaggedPlayerToGCMPlayer';
export const CAN_UNLINK_FLAGGED_PLAYER_TO_GCM_PLAYER = 'CanUnlinkFlaggedPlayerToGCMPlayer';
export const CAN_VIEW_PERSONAL_FLAGGED_HISTORY = 'CanViewPersonalFlaggedHistory';
export const CAN_BAR_FLAGGED_PLAYER = 'CanBarFlaggedPlayer';

// Alert
export const CAN_VIEW_ALERT_AND_HISTORY = 'CanViewAlertAndHistory';
export const CAN_LOCK_UNLOCK_ACK_ALERT = 'CanLockUnlockAckAlert';
export const CAN_LINK_TO_BARRED_PLAYER_FROM_ALERT = 'CanLinkToBarredPlayerFromAlert';
export const CAN_LINK_TO_FLAGGED_PLAYER_FROM_ALERT = 'CanLinkToFlaggedPlayerFromAlert';

// Barred reason
export const CAN_VIEW_BARRED_REASON = 'CanViewBarredReason';
export const CAN_ADD_BARRED_REASON = 'CanAddBarredReason';
export const CAN_DELETE_BARRED_REASON = 'CanDeleteBarredReason';
export const CAN_SORT_BARRED_REASON = 'CanSortBarredReason';

// No permission
export const NO_PERMISSION = 'NoPermission';

export const PERMISSION_LIST = 'permissionList';

export default {
  'S00001': CAN_LOGIN_SECURITY_MGM,

  'S00100': CAN_VIEW_BARRED_PLAYER_AND_HISTORY,
  'S00101': CAN_ADD_BARRED_PLAYER,
  'S00102': CAN_EDIT_BARRED_PLAYER,
  'S00103': CAN_DELETE_BARRED_PLAYER,
  'S00104': CAN_BATCH_UPLOAD_BARRED_PLAYER_LIST,
  'S00105': CAN_BATCH_UPLOAD_BARRED_PLAYER_PHOTO,
  'S00106': CAN_UPLOAD_BARRED_PLAYER_PHOTO,
  'S00107': CAN_EXPORT_BARRED_PLAYER_LIST,
  'S00108': CAN_UNBAR_BARRED_PLAYER,
  'S00109': CAN_LINK_BARRED_PLAYER_TO_GCM_PLAYER,
  'S00110': CAN_UNLINK_BARRED_PLAYER_TO_GCM_PLAYER,
  'S00111': CAN_VIEW_PERSONAL_BARRED_HISTORY,

  'S00200': CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY,
  'S00201': CAN_ADD_FLAGGED_PLAYER,
  'S00202': CAN_EDIT_FLAGGED_PLAYER,
  'S00203': CAN_DELETE_FLAGGED_PLAYER,
  'S00204': CAN_BATCH_UPLOAD_FLAGGED_PLAYER_LIST,
  'S00205': CAN_BATCH_UPLOAD_FLAGGED_PLAYER_PHOTO,
  'S00206': CAN_UPLOAD_FLAGGED_PLAYER_PHOTO,
  'S00207': CAN_EXPORT_FLAGGED_PLAYER_LIST,
  'S00208': CAN_UNFLAG_FLAGGED_PLAYER,
  'S00209': CAN_LINK_FLAGGED_PLAYER_TO_GCM_PLAYER,
  'S00210': CAN_UNLINK_FLAGGED_PLAYER_TO_GCM_PLAYER,
  'S00211': CAN_VIEW_PERSONAL_FLAGGED_HISTORY,
  'S00212': CAN_BAR_FLAGGED_PLAYER,

  'S00300': CAN_VIEW_ALERT_AND_HISTORY,
  'S00301': CAN_LOCK_UNLOCK_ACK_ALERT,
  'S00302': CAN_LINK_TO_BARRED_PLAYER_FROM_ALERT,
  'S00303': CAN_LINK_TO_FLAGGED_PLAYER_FROM_ALERT,

  'S00400': CAN_VIEW_BARRED_REASON,
  'S00401': CAN_ADD_BARRED_REASON,
  'S00402': CAN_DELETE_BARRED_REASON,
  'S00403': CAN_SORT_BARRED_REASON,
};

export function getPermissionConfig(functionPermission, modulePermission = []) {
  let permission = functionPermission;

  if (modulePermission.length > 0 && !hasPermission([...functionPermission, ...modulePermission])) {
    permission = [NO_PERMISSION];
  }

  return {
    permissions: {
      only: permission,
      redirectTo: '/no-permission'
    }
  };
}

export function getPermissionList() {
  return JSON.parse(sessionStorage.getItem(PERMISSION_LIST)) || [];
}

export function hasPermission(requiredPermissions) {
  const allPermissions = getPermissionList();
  return requiredPermissions.every(requiredPermission => allPermissions.find(item => item === requiredPermission));
}
