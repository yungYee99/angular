import * as Moment from 'moment';

export function getStartDateDisableSinceByEndDate(endDate) {
  const year = Moment(endDate).get('year');
  const month = Moment(endDate).get('month') + 1;
  const day = Moment(endDate).get('date');

  return { year, month, day };
}

export function getEndDateDisableUntilByStartDate(startDate) {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;
  const currentDay = new Date().getDate();
  const isToday = new Date().valueOf() > Moment(startDate).valueOf();

  const year = isToday ? currentYear : Moment(startDate).get('year');
  const month = isToday ? currentMonth : Moment(startDate).get('month') + 1;
  const day = isToday ? currentDay : Moment(startDate).get('date');

  return { year, month, day };
}
