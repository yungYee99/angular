export enum MessageStatus {
  Success,
  Error,
  Warn
}
