
export function formatName({ familyName, middleName, givenName }) {
  if (familyName || givenName) {
    return [familyName, middleName, givenName].join(' ');
  }

  return '';
}
