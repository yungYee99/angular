export const IMAGE_TYPE = '.gif, .png, .jpeg, .jpg';

export function isInvalidFileType(fileName, accept) {
  if (!fileName) {
    return true;
  }

  let picExt = '.' + fileName.substr(fileName.lastIndexOf('.') + 1);
  picExt = picExt.toLocaleLowerCase();
  const acceptedTypes = accept.split(', ');

  return !acceptedTypes.find(acceptedType => acceptedType === picExt);
}
