export function validateSubmitBannedPlayerBody(submitBannedPlayerBody) {
    if (!submitBannedPlayerBody.wynnId) {
      if (!submitBannedPlayerBody.familyName || !submitBannedPlayerBody.familyName.trim()) {
        return false;
      }
      if (!submitBannedPlayerBody.givenName || !submitBannedPlayerBody.givenName.trim()) {
        return false;
      }
    }

    if (!submitBannedPlayerBody.isBarred) {
      return true;
    }

    if (!submitBannedPlayerBody.bannedFrom) {
      return false;
    }
    if (!submitBannedPlayerBody.bannedTo && !submitBannedPlayerBody.isPermanent) {
      return false;
    }
    if (!submitBannedPlayerBody.isPermanent) {
      if (submitBannedPlayerBody.bannedFrom >= submitBannedPlayerBody.bannedTo || !submitBannedPlayerBody.bannedTo) {
        return false;
      }
    }
    if (!submitBannedPlayerBody.reason) {
      return false;
    }
    if (submitBannedPlayerBody.bannedArea.length < 1) {
      return false;
    }
    return true;
  }