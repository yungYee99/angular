import { Injectable, Inject } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest, HttpResponse } from '@angular/common/http';
import 'rxjs/add/operator/timeout';
import { EnvService } from './common/env-service/env.service';

import { tap } from 'rxjs/internal/operators/tap';
import { Router } from '@angular/router';
import { NgxPermissionsService } from 'ngx-permissions';
import Permissions, { PERMISSION_LIST } from './common/utils/permission';
import { CommonService } from './common/common-service';
import { UNHANDLED_SYSTEM_EXCEPTION, needShowErrorDialogCodes } from './common/utils/error-message';

export const LAST_REQUEST_TIME = 'lastrequesttime';
export const AUTHORIZATION = 'Authorization';
export const USER = 'user';
export const IDLE_TIME = 'idleTime';

@Injectable()

export class AppInterceptor implements HttpInterceptor {
  private lastrequesttime = '';
  private authorization = '';
  private noLoadingUrl = [
    { url: 'assets', method: '' },
    { url: 'wynnhub', method: '' },
    { url: 'players/photo', method: '' },
    { url: 'bannedLogs/photo', method: '' },
    { url: 'bannedLogs/upload', method: '' },
    { url: 'bannedLogs/export', method: '' },
    { url: 'alerts/count', method: '' },
    { url: 'tasks', method: 'POST' },
  ];
  private uploadUrl = ['bannedLogs/upload', 'bannedLogs/photo/upload'];

  private reqs = [];

  private cacheUrl = [];

  constructor(
    private permissionsService: NgxPermissionsService,
    private commonService: CommonService,
    public env: EnvService,
    private router: Router) { }

  intercept(req: HttpRequest<any>, next: HttpHandler) {

    this.initDataFromSession();
    let clonedReq = req;

    // request don't show the loading:
    // 1. the url within the noLoadingUrl array
    // 2. receive acknowledge alert notification(common.service.noLoading.value is true), refresh the alert list(url includes('alerts'))

    if (!((this.noLoadingUrl && this.noLoadingUrl.length > 0 && this.getNoLoadingIndex(req) > -1) ||
    (this.commonService.noLoading.value && clonedReq.url.includes('alerts')))) {
      this.reqs.push(clonedReq.url);
      this.commonService.isLoading.next(true);
    }

    // Fix IE 11 cors issue
    // 1. When custom header is empty, IE send OPTIONS request(cors preflight) and ignore these two header in Access-Control-Request-Headers
    // Access-Control-Request-Headers: accept
    //
    // 2. Server side(ASP.net Core) response doesn't include header: Access-Control-Allow-Headers, may be because "accept" header is default
    //
    // 3. Then IE report accept is not allowed
    if (this.authorization) {
      clonedReq = clonedReq.clone({
        setHeaders: {
          'Authorization': this.authorization
        }
      });
    }

    if (this.lastrequesttime) {
      clonedReq = clonedReq.clone({
        setHeaders: {
          'lastrequesttime': this.lastrequesttime
        }
      });
    }

    if (!(this.cacheUrl && this.cacheUrl.length > 0 && this.cacheUrl.findIndex(x => req.url.includes(x)) > -1)) {
      clonedReq = clonedReq.clone({
        setHeaders: {
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache',
        }
      });
    }
    const time = (this.uploadUrl.findIndex(x => req.url.includes(x)) > -1 ?
      this.env.uploadApiTimeoutInSec : this.env.securityApiTimeoutInSec) * 1000;

    return next.handle(clonedReq).timeout(time)
      .pipe(
        tap(
          event => this.refreshAuthority(event),
          error => this.handleError(error, clonedReq),
          () => this.completeRequest(clonedReq)
        )
      );
  }

  getNoLoadingIndex(req) {
    return this.noLoadingUrl.findIndex(x => {
      if (req.url.includes(x.url)) {
        if (x.method && x.method !== req.method) {
          return false;
        }
        return true;
      }
      return false;
    });
  }

  completeRequest(req) {
    this.reqs = this.reqs.filter(x => x !== req.url);
    if (!this.reqs || this.reqs.length === 0) {
      this.commonService.isLoading.next(false);
    }
  }

  private refreshAuthority(response) {
    if (response.headers == null) {
      return;
    }

    if (response.body && response.body.user) {
      sessionStorage.setItem(USER, JSON.stringify(response.body.user));
    }

    if (response.body && response.body.permissions) {
      const permissions = response.body.permissions.map(permissionCode => Permissions[permissionCode]);
      this.permissionsService.loadPermissions(permissions);
      sessionStorage.setItem(PERMISSION_LIST, JSON.stringify(permissions));
    }

    const lastRequestTime = response.headers.get(LAST_REQUEST_TIME);
    const authorization = response.headers.get(AUTHORIZATION);

    if (lastRequestTime != null) {
      this.lastrequesttime = lastRequestTime;
      sessionStorage.setItem(LAST_REQUEST_TIME, lastRequestTime);
    }

    // Login again on current page, response header will contain the authorization
    if (authorization != null) {
      this.authorization = `Bearer ${authorization}`;
      sessionStorage.setItem(AUTHORIZATION, authorization);
    }
  }

  private handleError(error, req) {
    this.completeRequest(req);

    if (error.status === 401) {
      sessionStorage.removeItem(USER);
      sessionStorage.removeItem(AUTHORIZATION);
      sessionStorage.removeItem(LAST_REQUEST_TIME);
      sessionStorage.removeItem(IDLE_TIME);
      sessionStorage.removeItem(PERMISSION_LIST);
      this.authorization = '';
      this.router.navigateByUrl('login');
      return;
    }

    // judge response status code
    const errorCode = (error.error && error.error.errorCode) || UNHANDLED_SYSTEM_EXCEPTION;

    // need show error dialog
    if (needShowErrorDialogCodes.find(item => item.toString() === errorCode.toString())) {
      this.commonService.errorCode.next(errorCode);
      this.commonService.hasApiError.next(true);
    }
  }

  private initDataFromSession() {
    // 1. First login 2. Token expired and login again
    if (this.authorization === '' && sessionStorage.getItem(AUTHORIZATION) != null) {
        this.authorization = `Bearer ${sessionStorage.getItem(AUTHORIZATION)}`;
    }
    if (this.lastrequesttime === '' && sessionStorage.getItem(LAST_REQUEST_TIME) != null) {
        this.lastrequesttime = sessionStorage.getItem(LAST_REQUEST_TIME);
    }
  }

}
