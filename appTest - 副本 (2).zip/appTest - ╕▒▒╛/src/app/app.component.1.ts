import { Component, OnInit, ViewChild  } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Location } from '@angular/common';
import { AUTHORIZATION, LAST_REQUEST_TIME, USER, IDLE_TIME } from './app.interceptor';
import { PERMISSION_LIST } from './common/utils/permission';
import { TranslateService } from '@ngx-translate/core';
import 'rxjs/add/operator/filter';
import { NgxPermissionsService } from 'ngx-permissions';
import { CommonService } from './common/common-service';
import { ModalDirective } from 'ng-uikit-pro-standard';
import { UNHANDLED_SYSTEM_EXCEPTION, ErrorMessage } from './common/utils/error-message';
import {Idle, DEFAULT_INTERRUPTSOURCES} from '@ng-idle/core';
import { CommonAction, UserAction } from './actions';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.css']

})

export class AppComponent implements OnInit {
  @ViewChild('commonErrorModal') commonErrorModal: ModalDirective;

  specialPage: boolean;

  isLogged: boolean;

  isLogInPage = true;

  user: any;

  commonError = { title: '', message: '' };
  reset = false;
  private currentUrl = '';

  constructor(
    private router: Router,
    private location: Location,
    private permissionsService: NgxPermissionsService,
    private translateService: TranslateService,
    public commonService: CommonService,
    private idle: Idle,
    private commonAction: CommonAction,
    private userAction: UserAction,
  ) {
    const authorization = sessionStorage.getItem(AUTHORIZATION);
    this.isLogged = authorization !== null;
    if (!this.isLogged) {
      this.router.navigateByUrl('login');
    }

    // Subscribe all events and do assignment cause the upgrade issue. Since last event changed from NavigationEnd to SCROLL after upgrade from mdb 6.2.0 to 6.2.2
    // TODO: Need to further review the usage of specialPage and isLogInPage
    this.router.events
      .filter(e => e instanceof NavigationEnd)
      .subscribe((route: any) => {
        this.currentUrl = route.url;
        this.isLogInPage = this.currentUrl === '/login';

        if (!this.isLogInPage && !this.reset) {
          this.resetIdle(idle);
        }
    });

    this.listenApiError();
  }

  resetIdle(idle) {
    const idleTime = parseInt(sessionStorage.getItem(IDLE_TIME), 10);

    this.reset = true;
    idle.setIdle(idleTime);
    idle.setTimeout(5);
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    idle.onTimeout.subscribe(() => {
      this.reset = false;
      this.commonAction.logout();
      this.userAction.logout(this.commonAction.getUser());
      this.router.navigateByUrl('login');
    });

    idle.watch();
  }

  ngOnInit(): void {
    this.translateService.addLangs(['zh', 'en']);
    this.translateService.setDefaultLang('en');
    this.initPermissions();
  }

  initPermissions() {
    const permissions = JSON.parse(sessionStorage.getItem(PERMISSION_LIST)) || [];
    this.permissionsService.loadPermissions(permissions);
  }

  goBack(): void {
    this.location.back();
  }

  listenApiError() {
    this.commonService.hasApiError.subscribe(data => {
      if (data) {
        this.commonErrorModal.show();
      }
    });

    this.commonService.errorCode.subscribe(data => {
      if (data) {
        this.commonError = ErrorMessage[data] || ErrorMessage[UNHANDLED_SYSTEM_EXCEPTION];
      }
    });
  }

  closeErrorDialog() {
    this.commonErrorModal.hide();
    this.commonService.hasApiError.next(false);
    this.commonService.errorCode.next('');
  }
}
