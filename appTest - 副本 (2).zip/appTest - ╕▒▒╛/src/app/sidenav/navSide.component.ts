import { Component } from '@angular/core';

@Component({
  selector: 'app-nav-side',
  templateUrl: './navSide.component.html',
  styleUrls: ['./navSide.component.css']
  })
  export class NavSideComponent { }
