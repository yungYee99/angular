import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { NgxPermissionsGuard } from 'ngx-permissions';

import { LoginComponent } from './pages/login/login.component';
import { AlertPageComponent } from './pages/alert-page/alert-page.component';
import { BarredPlayerComponent } from './pages/barred-player/barred-player.component';
import { BarredReasonSettingsComponent } from './pages/barred-reason-settings/barred-reason-settings.component';
import { AlertDetailComponent } from './pages/alert-detail/alert-detail.component';
import { BarredPlayerDetailComponent } from './pages/barred-player-detail/barred-player-detail.component';
import { PersonalBarredHistoryComponent } from './pages/personal-barred-history/personal-barred-history.component';
import { BarredHistorysComponent } from './pages/barred-historys/barred-historys.component';
import { AddBannedPlayerComponent } from './pages/add-banned-player/add-banned-player.component';
import { EditBannedPlayerComponent } from './pages/edit-banned-player/edit-banned-player.component';
import { NoPermissionComponent } from './pages/no-permission/no-permission.component';

import {
  getPermissionConfig,
  CAN_VIEW_ALERT_AND_HISTORY,
  CAN_VIEW_BARRED_REASON,
  CAN_VIEW_BARRED_PLAYER_AND_HISTORY,
  CAN_ADD_BARRED_PLAYER,
  CAN_EDIT_BARRED_PLAYER,
  CAN_VIEW_PERSONAL_BARRED_HISTORY,
  CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY,
  CAN_ADD_FLAGGED_PLAYER,
  CAN_EDIT_FLAGGED_PLAYER,
  CAN_BAR_FLAGGED_PLAYER,
  CAN_VIEW_PERSONAL_FLAGGED_HISTORY
} from './common/utils/permission';

const appRoutes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'alerts' },
  { path: 'login', component: LoginComponent },
  {
    path: 'alerts',
    component: AlertPageComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_ALERT_AND_HISTORY])
  },
  {
    path: 'alerts/:id',
    component: AlertDetailComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_ALERT_AND_HISTORY])
  },
  {
    path: 'alert-historys',
    component: AlertPageComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_ALERT_AND_HISTORY])
  },
  {
    path: 'alert-historys/:id',
    component: AlertDetailComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_ALERT_AND_HISTORY])
  },
  {
    path: 'barred-players',
    component: BarredPlayerComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_BARRED_PLAYER_AND_HISTORY])
  },
  {
    path: 'barred-players/add',
    component: AddBannedPlayerComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_ADD_BARRED_PLAYER], [CAN_VIEW_BARRED_PLAYER_AND_HISTORY])
  },
  {
    path: 'barred-players/:id',
    component: BarredPlayerDetailComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_BARRED_PLAYER_AND_HISTORY])
  },
  {
    path: 'barred-players/:id/edit',
    component: EditBannedPlayerComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_EDIT_BARRED_PLAYER], [CAN_VIEW_BARRED_PLAYER_AND_HISTORY])
  },
  {
    path: 'barred-players/:id/personal-history',
    component: PersonalBarredHistoryComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_PERSONAL_BARRED_HISTORY], [CAN_VIEW_BARRED_PLAYER_AND_HISTORY])
  },
  {
    path: 'barred-players/:id/personal-history/:historyId',
    component: BarredPlayerDetailComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_PERSONAL_BARRED_HISTORY], [CAN_VIEW_BARRED_PLAYER_AND_HISTORY])
  },
  {
    path: 'barred-historys',
    component: BarredHistorysComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_BARRED_PLAYER_AND_HISTORY])
  },
  {
    path: 'barred-historys/:id',
    component: BarredPlayerDetailComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_BARRED_PLAYER_AND_HISTORY])
  },
  {
    path: 'barred-historys/:id/personal-history',
    component: PersonalBarredHistoryComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_PERSONAL_BARRED_HISTORY], [CAN_VIEW_BARRED_PLAYER_AND_HISTORY])
  },
  {
    path: 'barred-historys/:id/personal-history/:historyId',
    component: BarredPlayerDetailComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_PERSONAL_BARRED_HISTORY], [CAN_VIEW_BARRED_PLAYER_AND_HISTORY])
  },
  {
    path: 'barred-reason-settings',
    component: BarredReasonSettingsComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_BARRED_REASON])
  },
  {
    path: 'flagged-players',
    component: BarredPlayerComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY])
  },
  {
    path: 'flagged-players/add',
    component: AddBannedPlayerComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_ADD_FLAGGED_PLAYER], [CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY])
  },
  {
    path: 'flagged-players/:id',
    component: BarredPlayerDetailComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY])
  },
  {
    path: 'flagged-players/:id/edit',
    component: EditBannedPlayerComponent ,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_EDIT_FLAGGED_PLAYER], [CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY])
  },
  {
    path: 'flagged-players/:id/barPlayer',
    component: EditBannedPlayerComponent ,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_BAR_FLAGGED_PLAYER], [CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY])
  },
  {
    path: 'flagged-players/:id/personal-history',
    component: PersonalBarredHistoryComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_PERSONAL_FLAGGED_HISTORY], [CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY])
  },
  {
    path: 'flagged-players/:id/personal-history/:historyId',
    component: BarredPlayerDetailComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_PERSONAL_FLAGGED_HISTORY], [CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY])
  },
  {
    path: 'flagged-historys',
    component: BarredHistorysComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY])
  },
  {
    path: 'flagged-historys/:id',
    component: BarredPlayerDetailComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY])
  },
  {
    path: 'flagged-historys/:id/personal-history',
    component: PersonalBarredHistoryComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_PERSONAL_FLAGGED_HISTORY], [CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY])
  },
  {
    path: 'flagged-historys/:id/personal-history/:historyId',
    component: BarredPlayerDetailComponent,
    canActivate: [NgxPermissionsGuard],
    data: getPermissionConfig([CAN_VIEW_PERSONAL_FLAGGED_HISTORY], [CAN_VIEW_FLAGGED_PLAYER_AND_HISTORY])
  },
  { path: 'no-permission', component: NoPermissionComponent },
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class AppRoutes { }
