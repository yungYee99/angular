import { ToastModule } from 'ng-uikit-pro-standard';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule, HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { AppComponent } from './app.component';
import { AppRoutes } from './app.routes.module';
import { AppInterceptor } from './app.interceptor';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { DatePipe } from '@angular/common';

import { SharedModule } from './shared/shared.module';
import { MDBSpinningPreloader } from 'ng-uikit-pro-standard';
import { NgxPermissionsModule } from 'ngx-permissions';
import { NgIdleModule } from '@ng-idle/core';

// main layout
import { PlayerCardComponent } from './components/player-card/player-card.component';
import { LoginComponent } from './pages/login/login.component';
import { HeaderComponent } from './components/header/header.component';
import { SideColumnComponent } from './components/side-column/side-column.component';
import { AlertPageComponent } from './pages/alert-page/alert-page.component';
import { BarredPlayerComponent } from './pages/barred-player/barred-player.component';
import { FlaggedPlayerComponent } from './pages/flagged-player/flagged-player.component';
import { SettingsPageComponent } from './pages/settings-page/settings-page.component';
import { FilterBarComponent } from './components/filter-bar/filter-bar.component';
import { CommonAction } from './actions/common/common.action';
import { PaginationListComponent } from './components/pagination/pagination-list.component';
import { ApiModule, BASE_PATH, Configuration } from '../app/service/index';
import { BarredReasonSettingsComponent } from './pages/barred-reason-settings/barred-reason-settings.component';
import { ConfirmDialogComponent } from './components/confirm-dialog/confirm-dialog.component';
import { LinkPlayerDialogComponent } from './components/link-player-dialog/link-player-dialog.component';
import { AlertDetailComponent } from './pages/alert-detail/alert-detail.component';
import { BreadCrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { BarredPlayerDetailComponent } from './pages/barred-player-detail/barred-player-detail.component';
import { PersonalBarredHistoryComponent } from './pages/personal-barred-history/personal-barred-history.component';
import { BarredHistorysComponent } from './pages/barred-historys/barred-historys.component';
import { CheckboxGroupComponent } from './components/checkbox-group/checkbox-group.component';
import { AddBannedPlayerComponent } from './pages/add-banned-player/add-banned-player.component';
import { EditBannedPlayerComponent } from './pages/edit-banned-player/edit-banned-player.component';
import { UpdateBannedPlayerComponent } from './components/update-banned-player/update-banned-player.component';
import { UpdatePlayerComponent } from './components/update-player/update-player.component';
import { BannedInfoComponent } from './components/banned-info/banned-info.component';
import { NavigationComponent } from './components/navigation/navigation.component';
import { TextareaDialogComponent } from './components/textarea-dialog/textarea-dialog.component';
import { FileUploaderComponent } from './components/file-uploader/file-uploader.component';
import { PlayerImageComponent } from './components/play-image/player-image.component';
import { BarredSearchConditionComponent } from './components/barred-search-condition/barred-search-condition.component';
import { GsmSelectComponent } from './components/gsm-select/gsm-select.component';
import { GsmDatePickerComponent } from './components/gsm-date-picker/gsm-date-picker.component';
import { GsmTimePickerComponent } from './components/gsm-time-picker/gsm-time-picker.component';
import { GsmInputComponent } from './components/gsm-input/gsm-input.component';
import { GsmLoadSpinnerComponent } from './components/gsm-load-spinner/gsm-load-spinner.component';
import { EnvServiceProvider } from './common/env-service/env.service.provider';
import { NoPermissionComponent } from './pages/no-permission/no-permission.component';
import { UploadResultDialogComponent } from './components/upload-result-dialog/upload-result-dialog.component';

// i18n
export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    PlayerCardComponent,
    LoginComponent,
    SideColumnComponent,
    AlertPageComponent,
    BarredPlayerComponent,
    FlaggedPlayerComponent,
    SettingsPageComponent,
    FilterBarComponent,
    PaginationListComponent,
    BarredReasonSettingsComponent,
    ConfirmDialogComponent,
    LinkPlayerDialogComponent,
    AlertDetailComponent,
    BreadCrumbComponent,
    BarredPlayerDetailComponent,
    PersonalBarredHistoryComponent,
    BarredHistorysComponent,
    CheckboxGroupComponent,
    AddBannedPlayerComponent,
    EditBannedPlayerComponent,
    UpdateBannedPlayerComponent,
    UpdatePlayerComponent,
    BannedInfoComponent,
    NavigationComponent,
    TextareaDialogComponent,
    FileUploaderComponent,
    PlayerImageComponent,
    BarredSearchConditionComponent,
    GsmSelectComponent,
    GsmDatePickerComponent,
    GsmInputComponent,
    GsmTimePickerComponent,
    GsmLoadSpinnerComponent,
    NoPermissionComponent,
    UploadResultDialogComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutes,
    HttpClientModule,
    RouterModule,
    FormsModule,
    SharedModule,
    ToastModule.forRoot({maxOpened: 1}),
    NgxPermissionsModule.forRoot(),
    ReactiveFormsModule,
    ApiModule.forRoot(apiConfig),
    NgIdleModule.forRoot(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  providers: [
    MDBSpinningPreloader,
    EnvServiceProvider,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AppInterceptor,
      multi: true
    },
    {
      provide: BASE_PATH, useValue: EnvServiceProvider.useFactory().securityApiBaseUrl
    },
    DatePipe,
    CommonAction],
  bootstrap: [AppComponent],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }

// place holder
export function apiConfig() {
  return new Configuration({
    apiKeys: {},
  });
}
